#include<bits/stdc++.h>
using namespace std;
int main(){
    long long a;
    cin>>a;
    for(int i=1;i<=a;i++){
        cout<<i<<endl;
    }
    return 0;
}
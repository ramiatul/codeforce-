#include<bits/stdc++.h>
using namespace std;
int main(){
    long long a,b;
    b=1;
    for(int i=0;i<b;i--){
        cin>>a;
        if(a==1999){
            cout<<"Correct"<<endl;
            break;
        }else{
            cout<<"Wrong"<<endl;
        }
    }

}
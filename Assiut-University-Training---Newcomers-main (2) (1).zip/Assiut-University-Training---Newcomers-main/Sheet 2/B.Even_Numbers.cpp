#include<bits/stdc++.h>
using namespace std;
int main(){
    long long a;
    cin>>a;
    if(a==1){
        cout<<-1<<endl;
    }else{
    for(int i =1;i<=a;i++){
        if(i%2 == 0){
            cout<<i<<endl;
        }
    }}
}
#include<bits/stdc++.h>
using namespace std;
int main(){
    long long a;
    cin>>a;
    for(int i=1;i<=12;i++){
        cout<<a<<" * "<<i<<" = "<<a*i<<endl;
    }
    return 0;
}
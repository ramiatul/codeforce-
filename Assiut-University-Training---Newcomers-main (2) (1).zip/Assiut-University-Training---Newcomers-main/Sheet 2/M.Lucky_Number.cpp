#include<bits/stdc++.h>
using namespace std;
int main(){
    long long a,b;
    cin>>a>>b;
    if(a<=4 && b>=7){
        cout<<"4 7";
    }else{
        cout<<"-1";
    }
}
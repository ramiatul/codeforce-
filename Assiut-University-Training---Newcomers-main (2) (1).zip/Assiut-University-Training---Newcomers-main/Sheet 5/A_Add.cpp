#include<bits/stdc++.h>
using namespace std;
void solve(long long a, long long b);
int main(){
    long long a,b;
    cin>>a>>b;
    solve(a,b);
}
void solve(long long a, long long b){
    cout<<a+b;
}
